#if !defined(EDITOT_H)
#define EDITOT_H

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "shell.h"

void getCmdLine(char *input);

#endif  // EDITOT_H
